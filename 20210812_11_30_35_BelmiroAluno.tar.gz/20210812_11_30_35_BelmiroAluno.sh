#!/bin/bash
#by BSBAUDIOVISUAIS
echo "Esta é a data de Atual:"
date
   echo ""
   echo "Digite o nome da Diretoria a compactar: "
   read arqcompactado

   echo ""
   echo "Digite o nome dos arquivos que serão compactados [20210812_12_21_12_BelmiroAluno.txt outro.pdf index.html]: "
   read arq

   compactar=$(tar -zcvf $arqcompactado.tar.gz $arq)
   echo "A compactar arquivos..."
   sleep 4
   echo "$compactar"

echo "Compactação bem sucedida!"

